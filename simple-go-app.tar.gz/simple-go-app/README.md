# simple-go-app

This is a simple go app built using [Gin](https://github.com/gin-gonic/gin). It exposes a single endpoint on port `:8080` and returns the hostname of the device.

This is part of a turorial you can find here: https://www.schofield.dev/posts/2020-05-05-shuttleops-load-balanced-microservice/

