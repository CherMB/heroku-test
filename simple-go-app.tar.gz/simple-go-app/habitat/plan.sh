pkg_name=simple-go-app
pkg_origin=gscho
pkg_version="0.1.0"
pkg_scaffolding=core/scaffolding-go
pkg_deps=(core/glibc)
scaffolding_go_module=on
pkg_bin_dirs=(bin)
